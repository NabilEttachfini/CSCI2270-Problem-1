// Nabil Ettachfini
// CSCI 2270, Elle Boese
// TA:Yang :)
// Fall 2016
// Homework #4

#include <iostream>
#include <string>
#include  <list>
#include <cctype>
#include  "MovieTree.hpp"


using namespace std;
 string toLowercase(string instr);


MovieTree :: MovieTree()
{
    root = NULL;
}

MovieTree :: ~MovieTree(){ // this will delete the tree
    MovieNode* tree= root;
    list <MovieNode*> myQ;
    // myQ.push_back(root);
    while(tree != NULL)
    {
        if( tree->leftChild)
        {
            myQ.push_back( tree->leftChild);
        }
        if( tree->rightChild)
        {
            myQ.push_back( tree->rightChild);
        }
        delete tree;
        if( !myQ.empty())
        {
            tree= myQ.front();
            myQ.pop_front();
        }
        else{
            tree = NULL;
        }
    }
}
void MovieTree :: printMovieInventory()
{
    printMovieInventory(root);
}

#include <iostream> // for debugging purposes
void MovieTree ::  addMovieNode(int ranking, string title, int releaseYear, int quantity) // this might be a little messed up
{
    //cout << "Commencing adding node" << endl;
    // DO NOT FORGET TO CONVERT THINGS TO LOWERCASE!! YOU GOT THIS NABIL
    MovieNode* newNode= new MovieNode(ranking, title, releaseYear , quantity);
    newNode-> parent=NULL;
    newNode->leftChild=NULL;
    newNode->rightChild=NULL;
    
    if (!root)
    {
        root = newNode;
        //cout << "Adding root node, " << title << endl;
        return;
    }
    
    MovieNode* tmp1= root;
    MovieNode*  momdad= tmp1;
    
    while (tmp1)
    {
        momdad=tmp1;
        if( toLowercase(title) < toLowercase( tmp1->title)) // make sure this works, and this should compare the titles.
        {
            tmp1=tmp1->leftChild;
        }
        else tmp1=tmp1-> rightChild;
    }
   //  MovieNode* root= new MovieNode (ranking,title,releaseYear, quantity);
    // while(!tmp1)
  //  {
        // momdad=root; this is not needed
    
    //cout << "Adding " << title << " to list, ";
    
        if( toLowercase(title)  < toLowercase(momdad->title)) // not too sure what it needs to be less than on, also i changed the parent to tmp1, check if works after rest is complete
        {
            momdad->leftChild = newNode;
            
            //cout << "left child" << endl;
        }
        else
        {
            momdad->rightChild = newNode;
            
            //cout << "right child" << endl;
        }
  //  }
    
    newNode->parent = momdad;
  //  tmp1->rightChild=NULL;
   //  tmp1->leftChild=NULL;
}

    // might need to set things to null again, check with CA at office hours
    
    
    void MovieTree :: findMovie(string title) // COME BACK AND FIX THIS MY DUDE
    {
        MovieNode* foundMovie=search(title); // changed all to foundMovie to match the cout statments provided
        if(!foundMovie) // essentailly this is like saying if it's equal to NULL
        {
            cout << "Movie not found." << endl;
        }
        else{
        cout << "Movie Info:" << endl;
        cout << "===========" << endl;
        cout << "Ranking:" << foundMovie->ranking << endl;
        cout << "Title:" << foundMovie->title << endl;
        cout << "Year:" << foundMovie->year << endl;
        cout << "Quantity:" << foundMovie->quantity << endl;
        }
    }
    void MovieTree :: rentMovie(string title)
    {
        MovieNode* foundMovie=search(title); // does this need to be foundMovie? because of the cout
        
        if(foundMovie == NULL)  // FIND A CLEANER WAY TO DO THIS
        {
            cout << "Movie not found." << endl;
        }
        
       else if( foundMovie->quantity !=0) // changed all to foundMovie to match the cout statments provided
        {
             foundMovie->quantity --;    // this should take the quantity of that movie and take one out once rented.
            cout << "Movie has been rented." << endl;
            cout << "Movie Info:" << endl;
            cout << "===========" << endl;
            cout << "Ranking:" << foundMovie->ranking << endl;
            cout << "Title:" << foundMovie->title << endl;
            cout << "Year:" << foundMovie->year << endl;
            cout << "Quantity:" << foundMovie->quantity << endl;
        }
        else
            cout << "Movie out of stock." << endl;
    }

void MovieTree :: printMovieInventory(MovieNode * node)
{
        if(node)
        {
            printMovieInventory (node-> leftChild); // this is like what we did in class.
            cout << "Movie: "<< node->title <<" "<< node->quantity <<endl;
            printMovieInventory (node->rightChild);
            
        }
    }


    MovieNode * MovieTree :: search (string title)  // Do this first, because the other functions use this. i got rid of the std::
{
    
    
        if( root == NULL)
        {
            return NULL;
        }
        MovieNode* tmp2= root;
        while(tmp2){
            
            if (toLowercase(tmp2->title)  == toLowercase(title))
            {
                return tmp2;
            }
            if( toLowercase(title)  < toLowercase (tmp2->title)) // maybe do not even need the momdad part
            {
                tmp2=tmp2->leftChild;
            }
            else tmp2=tmp2->rightChild;
        }
        return NULL;
    }

string toLowercase(string instr)
{
    string outstr = instr;
    for (int i = 0; i < instr.length(); i++)
    {
        outstr[i] = tolower(instr[i]);
    }
    return outstr;
}




